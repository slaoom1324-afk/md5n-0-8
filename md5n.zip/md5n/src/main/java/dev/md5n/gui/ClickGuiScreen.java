package dev.md5n.gui;

import dev.md5n.Md5n;
import dev.md5n.config.ConfigManager;
import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.module.modules.ThemeSettings;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.KeySetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.setting.Setting;
import dev.md5n.util.Draw;
import dev.md5n.util.Sfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class ClickGuiScreen extends Screen {
    private static final int MARGIN = 12;
    private static final int BAR = 20;

    private static final class PanelState {
        int x, y;
        boolean collapsed;
        int scroll;
    }

    // تبقى مكان اللوحات والمودات المفتوحة بين مرة وثانية
    private static final Map<Category, PanelState> STATES = new EnumMap<>(Category.class);
    private static final Set<Module> EXPANDED = new HashSet<>();

    private final Map<Object, Float> hoverAnim = new HashMap<>();
    private final Map<Object, Float> toggleAnim = new HashMap<>();

    private record Row(Module module, Setting setting, int y) {}

    private Object binding;            // Module أو Setting ينتظر مفتاح
    private NumSetting dragSlider;
    private int dragSliderX;
    private PanelState dragPanel;
    private int dragOffX, dragOffY, pressX, pressY;
    private boolean dragMoved;

    private String search = "";
    private final long openTime = System.currentTimeMillis();
    private long lastNs;
    private float openP = 1f;
    private String tipTitle, tipText;

    private ThemeSettings theme;
    private int w = 150, h = 16;

    public ClickGuiScreen() {
        super(Text.literal("md5n"));
        Sfx.open();
    }

    // ---------------------------------------------------------------- مساعدات

    private void refresh() {
        theme = Md5n.modules.get(ThemeSettings.class);
        w = theme.panelWidth();
        h = theme.rowHeight();
        int i = 0;
        int perRow = Math.max(1, (width - MARGIN) / (w + 10));
        for (Category c : Category.values()) {
            if (!STATES.containsKey(c)) {
                PanelState st = new PanelState();
                st.x = MARGIN + (i % perRow) * (w + 10);
                st.y = BAR + 10 + (i / perRow) * 150;
                STATES.put(c, st);
            }
            i++;
        }
    }

    private int headerH() { return h + 4; }

    private List<Module> modulesOf(Category c) {
        List<Module> list = new ArrayList<>();
        String q = search.toLowerCase(Locale.ROOT);
        for (Module m : Md5n.modules.all()) {
            if (m.category != c) continue;
            if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)) continue;
            list.add(m);
        }
        return list;
    }

    private boolean visible(Category c) {
        return search.isEmpty() || !modulesOf(c).isEmpty();
    }

    private List<Row> rows(Category c, PanelState st) {
        List<Row> rows = new ArrayList<>();
        int y = st.y + headerH() - st.scroll;
        for (Module m : modulesOf(c)) {
            rows.add(new Row(m, null, y));
            y += h;
            if (EXPANDED.contains(m)) {
                for (Setting s : m.settings()) {
                    rows.add(new Row(m, s, y));
                    y += h;
                }
            }
        }
        return rows;
    }

    private int contentHeight(Category c) {
        int n = 0;
        for (Module m : modulesOf(c)) {
            n++;
            if (EXPANDED.contains(m)) n += m.settings().size();
        }
        return n * h;
    }

    private int bodyHeight(Category c, PanelState st) {
        if (st.collapsed) return 0;
        int avail = height - (st.y + headerH()) - 20;
        return Math.max(0, Math.min(contentHeight(c), avail));
    }

    private int maxScroll(Category c, PanelState st) {
        return Math.max(0, contentHeight(c) - bodyHeight(c, st));
    }

    private static boolean inside(double mx, double my, int x, int y, int bw, int bh) {
        return mx >= x && mx < x + bw && my >= y && my < y + bh;
    }

    private static String keyName(int code) {
        return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString();
    }

    private int c(int color) {
        int a = (int) (((color >>> 24) & 0xFF) * openP);
        return (a << 24) | (color & 0x00FFFFFF);
    }

    private static int withAlpha(int color, float f) {
        int a = (int) (((color >>> 24) & 0xFF) * f);
        return (a << 24) | (color & 0x00FFFFFF);
    }

    private static int lerpColor(int a, int b, float t) {
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int ra = (int) (aa + (ba - aa) * t);
        int rr = (int) (ar + (br - ar) * t);
        int rg = (int) (ag + (bg - ag) * t);
        int rb = (int) (ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    private float approach(Map<Object, Float> map, Object key, float target, float step) {
        float cur = map.getOrDefault(key, target);
        if (!theme.animations()) cur = target;
        else if (cur < target) cur = Math.min(target, cur + step);
        else if (cur > target) cur = Math.max(target, cur - step);
        map.put(key, cur);
        return cur;
    }

    private void fill(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y2, c(color));
    }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        int col = c(color);
        if ((col >>> 24) < 12) return;
        ctx.drawTextWithShadow(textRenderer, s, x, y, col);
    }

    // ---------------------------------------------------------------- الرسم

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        refresh();

        long nowNs = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (nowNs - lastNs) / 1_000_000_000f);
        lastNs = nowNs;

        float t = Math.min(1f, (System.currentTimeMillis() - openTime) / 220f);
        openP = theme.animations() ? 1f - (1f - t) * (1f - t) * (1f - t) : 1f;
        int oy = theme.animations() ? (int) ((1f - openP) * -10f) : 0;

        int accent = theme.accent();
        boolean glass = theme.glass();
        float pulse = (float) (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 700.0));
        tipTitle = null;
        tipText = null;

        // --- الشريط العلوي
        int total = 0, active = 0;
        for (Module m : Md5n.modules.all()) {
            if (!m.hasToggle()) continue;
            total++;
            if (m.isEnabled()) active++;
        }
        fill(ctx, 0, 0, width, BAR, withAlpha(theme.header(), 0.92f));
        fill(ctx, 0, BAR, width, BAR + 1, withAlpha(accent, 0.7f));
        text(ctx, Md5n.NAME + " " + Md5n.VERSION, 8, 6, accent);

        int sw = 150, sx = width / 2 - sw / 2;
        if (glass) Draw.roundRect(ctx, sx, 4, sx + sw, BAR - 4, 4, c(theme.off()));
        else fill(ctx, sx, 4, sx + sw, BAR - 4, theme.off());
        String cursor = ((System.currentTimeMillis() / 500) % 2 == 0) ? "_" : "";
        String shown = search.isEmpty() ? "Type to search..." : search + cursor;
        text(ctx, shown, sx + 4, 6, search.isEmpty() ? theme.subtext() : theme.text());

        String stats = active + "/" + total + " active";
        text(ctx, stats, width - 8 - textRenderer.getWidth(stats), 6, theme.subtext());

        // --- اللوحات
        for (Category cat : Category.values()) {
            if (!visible(cat)) continue;
            PanelState st = STATES.get(cat);
            List<Module> mods = modulesOf(cat);
            int hh = headerH();
            int body = bodyHeight(cat, st);
            if (!st.collapsed) st.scroll = MathHelper.clamp(st.scroll, 0, maxScroll(cat, st));
            int top = st.y + oy;

            if (glass) {
                Draw.glass(ctx, st.x, top, st.x + w, top + hh + body + 3, 6,
                        c(withAlpha(theme.header(), 0.80f)),
                        c(withAlpha(accent, 0.45f + 0.15f * pulse)),
                        c(withAlpha(accent, 0.07f)));
                fill(ctx, st.x + 6, top + hh - 1, st.x + w - 6, top + hh, withAlpha(accent, 0.35f));
            } else {
                fill(ctx, st.x - 1, top - 1, st.x + w + 1, top + hh + body + 2, 0x66000000);
                fill(ctx, st.x, top, st.x + w, top + hh, theme.header());
                fill(ctx, st.x, top, st.x + 2, top + hh, accent);
            }
            int hty = top + (hh - 8) / 2;
            text(ctx, cat.label, st.x + 7, hty, accent);
            String right = mods.size() + "  " + (st.collapsed ? ">" : "v");
            text(ctx, right, st.x + w - 6 - textRenderer.getWidth(right), hty, theme.subtext());

            if (body > 0) {
                int bodyTop = top + hh;
                ctx.enableScissor(st.x, bodyTop, st.x + w, bodyTop + body);
                for (Row r : rows(cat, st)) {
                    int ry = r.y() + oy;
                    if (ry + h < bodyTop || ry > bodyTop + body) continue;
                    boolean hover = inside(mouseX, mouseY, st.x, ry, w, h)
                            && mouseY >= bodyTop && mouseY < bodyTop + body;
                    if (r.setting() == null) {
                        drawModuleRow(ctx, r.module(), st.x, ry, hover, dt, accent);
                    } else {
                        drawSettingRow(ctx, r.setting(), st.x, ry, hover, dt, accent);
                    }
                }
                ctx.disableScissor();

                // شريط التمرير
                int content = contentHeight(cat);
                if (content > body) {
                    int thumb = Math.max(10, body * body / content);
                    int travel = body - thumb;
                    int ms = maxScroll(cat, st);
                    int ty = bodyTop + (ms == 0 ? 0 : travel * st.scroll / ms);
                    fill(ctx, st.x + w - 2, ty, st.x + w, ty + thumb, withAlpha(accent, 0.8f));
                }
                if (!glass) fill(ctx, st.x, bodyTop + body, st.x + w, bodyTop + body + 1, withAlpha(accent, 0.6f));
            }
        }

        // --- الشريط السفلي
        fill(ctx, 0, height - 16, width, height, withAlpha(theme.header(), 0.92f));
        String hint = binding != null
                ? "Press a key to bind  (Backspace = clear, Esc = cancel)"
                : "LMB toggle  |  RMB settings  |  MMB bind key  |  Drag headers  |  Scroll";
        text(ctx, hint, 8, height - 12, theme.subtext());

        // --- التلميح
        if (tipText != null && !tipText.isEmpty()) {
            int tw = Math.max(textRenderer.getWidth(tipText), textRenderer.getWidth(tipTitle)) + 10;
            int tx = Math.min(mouseX + 12, width - tw - 4);
            int ty = Math.min(mouseY + 12, height - 44);
            fill(ctx, tx - 1, ty - 1, tx + tw + 1, ty + 25, withAlpha(accent, 0.85f));
            fill(ctx, tx, ty, tx + tw, ty + 24, 0xF0101018);
            text(ctx, tipTitle, tx + 5, ty + 3, accent);
            text(ctx, tipText, tx + 5, ty + 13, 0xFFCCCCCC);
        }
    }

    private void drawModuleRow(DrawContext ctx, Module m, int x, int y, boolean hover, float dt, int accent) {
        float ha = approach(hoverAnim, m, hover ? 1f : 0f, dt * 12f);
        float ea = approach(toggleAnim, m, (m.hasToggle() && m.isEnabled()) ? 1f : 0f, dt * 10f);
        int bg = lerpColor(lerpColor(theme.off(), theme.hover(), ha), theme.on(), ea);
        if (theme.glass()) {
            Draw.roundRect(ctx, x + 3, y + 1, x + w - 3, y + h - 1, 3, c(withAlpha(bg, 0.85f)));
            if (ea > 0.02f) fill(ctx, x + 4, y + 4, x + 6, y + h - 4, withAlpha(accent, ea));
        } else {
            fill(ctx, x, y, x + w, y + h, bg);
            if (ea > 0.02f) fill(ctx, x, y, x + 2, y + h, withAlpha(accent, ea));
        }

        int ty = y + (h - 8) / 2;
        text(ctx, m.name, x + 7, ty, theme.text());

        int right = x + w - 5;
        if (!m.settings().isEmpty()) {
            String arrow = EXPANDED.contains(m) ? "v" : ">";
            right -= textRenderer.getWidth(arrow);
            text(ctx, arrow, right, ty, theme.subtext());
            right -= 6;
        }
        String bind = binding == m ? "..." : (m.getKey() >= 0 ? "[" + keyName(m.getKey()) + "]" : "");
        if (!bind.isEmpty()) {
            right -= textRenderer.getWidth(bind);
            text(ctx, bind, right, ty, theme.bind());
        }

        if (hover) {
            tipTitle = m.name;
            tipText = m.description;
        }
    }

    private int drawBindTag(DrawContext ctx, Setting s, int right, int ty) {
        String bind = binding == s ? "..." : (s.getKey() >= 0 ? "[" + keyName(s.getKey()) + "]" : "");
        if (bind.isEmpty()) return right;
        int nr = right - textRenderer.getWidth(bind);
        text(ctx, bind, nr, ty, theme.bind());
        return nr - 5;
    }

    private void drawSettingRow(DrawContext ctx, Setting s, int x, int y, boolean hover, float dt, int accent) {
        float ha = approach(hoverAnim, s, hover ? 1f : 0f, dt * 12f);
        int settingBg = lerpColor(theme.setting(), theme.settingHover(), ha);
        if (theme.glass()) Draw.roundRect(ctx, x + 3, y, x + w - 3, y + h, 2, c(withAlpha(settingBg, 0.75f)));
        else fill(ctx, x, y, x + w, y + h, settingBg);
        fill(ctx, x + 4, y, x + 5, y + h, withAlpha(accent, 0.45f));

        int ty = y + (h - 8) / 2;
        int right = x + w - 6;

        if (s instanceof BoolSetting b) {
            float sa = approach(toggleAnim, s, b.get() ? 1f : 0f, dt * 10f);
            int tw = 18, th = 8;
            int tx = right - tw;
            int tyy = y + (h - th) / 2;
            fill(ctx, tx, tyy, tx + tw, tyy + th, lerpColor(theme.track(), theme.good(), sa));
            int kx = tx + 1 + (int) ((tw - 8) * sa);
            fill(ctx, kx, tyy + 1, kx + 6, tyy + th - 1, 0xFFFFFFFF);
            drawBindTag(ctx, s, tx - 5, ty);
            text(ctx, s.name, x + 10, ty, theme.text());
        } else if (s instanceof ModeSetting ms) {
            String v = "< " + ms.get() + " >";
            int vw = textRenderer.getWidth(v);
            text(ctx, v, right - vw, ty, accent);
            drawBindTag(ctx, s, right - vw - 5, ty);
            text(ctx, s.name, x + 10, ty, theme.text());
        } else if (s instanceof KeySetting) {
            String v = binding == s ? "..." : (s.getKey() >= 0 ? "[" + keyName(s.getKey()) + "]" : "None");
            text(ctx, v, right - textRenderer.getWidth(v), ty, theme.bind());
            text(ctx, s.name, x + 10, ty, theme.text());
        } else if (s instanceof NumSetting n) {
            int ny = y + 2;
            String v = n.display();
            text(ctx, s.name, x + 10, ny, theme.text());
            text(ctx, v, right - textRenderer.getWidth(v), ny, accent);

            int bx = x + 8, bw = w - 16, by = y + h - 5;
            int fw = (int) (bw * n.fraction());
            fill(ctx, bx, by, bx + bw, by + 2, theme.track());
            fill(ctx, bx, by, bx + fw, by + 2, accent);
            fill(ctx, bx + fw - 1, by - 2, bx + fw + 2, by + 4, accent);
        }

        if (hover) {
            tipTitle = s.name;
            tipText = s.description + (s.keyable() ? "   [MMB = bind key]" : "");
        }
    }

    // ---------------------------------------------------------------- الماوس

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        refresh();
        if (binding != null) {
            binding = null;
            return true;
        }
        for (Category cat : Category.values()) {
            if (!visible(cat)) continue;
            PanelState st = STATES.get(cat);
            int hh = headerH();

            if (inside(mx, my, st.x, st.y, w, hh)) {
                if (button == 0) {
                    dragPanel = st;
                    dragOffX = (int) mx - st.x;
                    dragOffY = (int) my - st.y;
                    pressX = (int) mx;
                    pressY = (int) my;
                    dragMoved = false;
                } else if (button == 1) {
                    st.collapsed = !st.collapsed;
                    Sfx.click();
                }
                return true;
            }

            if (st.collapsed) continue;
            int body = bodyHeight(cat, st);
            if (!inside(mx, my, st.x, st.y + hh, w, body)) continue;

            for (Row r : rows(cat, st)) {
                if (my < r.y() || my >= r.y() + h) continue;
                handleRowClick(r, st, mx, button);
                return true;
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void toggleExpand(Module m) {
        if (m.settings().isEmpty()) return;
        if (!EXPANDED.remove(m)) EXPANDED.add(m);
        Sfx.click();
    }

    private void handleRowClick(Row r, PanelState st, double mx, int button) {
        if (r.setting() == null) {
            Module m = r.module();
            if (button == 0) {
                if (m.hasToggle()) m.toggle(); else toggleExpand(m);
            } else if (button == 1) {
                toggleExpand(m);
            } else if (button == 2 && m.hasToggle()) {
                binding = (binding == m) ? null : m;
            }
            return;
        }

        Setting s = r.setting();
        if (s instanceof BoolSetting b) {
            if (button == 0) { b.toggle(); Sfx.click(); }
            else if (button == 2) binding = (binding == s) ? null : s;
        } else if (s instanceof ModeSetting ms) {
            if (button == 0) { ms.next(); Sfx.click(); }
            else if (button == 1) { ms.prev(); Sfx.click(); }
            else if (button == 2) binding = (binding == s) ? null : s;
        } else if (s instanceof KeySetting) {
            if (button == 0) binding = (binding == s) ? null : s;
            else if (button == 2) { s.setKey(-1); Sfx.click(); }
        } else if (s instanceof NumSetting n) {
            if (button == 0) {
                dragSlider = n;
                dragSliderX = st.x;
                setFromMouse(n, mx, st.x);
            }
        }
    }

    private void setFromMouse(NumSetting n, double mx, int panelX) {
        double frac = MathHelper.clamp((mx - (panelX + 8)) / (w - 16), 0.0, 1.0);
        n.set(n.min + frac * (n.max - n.min));
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragSlider != null && button == 0) {
            setFromMouse(dragSlider, mx, dragSliderX);
            return true;
        }
        if (dragPanel != null && button == 0) {
            if (!dragMoved && (Math.abs(mx - pressX) > 3 || Math.abs(my - pressY) > 3)) dragMoved = true;
            if (dragMoved) {
                dragPanel.x = MathHelper.clamp((int) mx - dragOffX, 0, Math.max(0, width - w));
                dragPanel.y = MathHelper.clamp((int) my - dragOffY, BAR + 2, Math.max(BAR + 2, height - 40));
            }
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragPanel != null && !dragMoved && button == 0) {
            dragPanel.collapsed = !dragPanel.collapsed;
            Sfx.click();
        }
        dragPanel = null;
        dragSlider = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontalAmount, double verticalAmount) {
        refresh();
        for (Category cat : Category.values()) {
            if (!visible(cat)) continue;
            PanelState st = STATES.get(cat);
            if (st.collapsed) continue;
            int hh = headerH();
            if (!inside(mx, my, st.x, st.y, w, hh + bodyHeight(cat, st))) continue;
            st.scroll = MathHelper.clamp(st.scroll - (int) (verticalAmount * 12), 0, maxScroll(cat, st));
            return true;
        }
        return true;
    }

    // ---------------------------------------------------------------- الكيبورد

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (binding != null) return true;
        if (System.currentTimeMillis() - openTime < 300) return true;   // تجاهل ضغطة فتح القائمة
        if (chr == ' ' && search.isEmpty()) return true;
        if (chr >= 32 && chr != 127 && search.length() < 24) {
            search += chr;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        refresh();

        if (binding != null) {
            int newKey = keyCode;
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) newKey = -1;
            if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                if (binding instanceof Module m) m.setKey(newKey);
                else if (binding instanceof Setting s) s.setKey(newKey);
                Sfx.click();
            }
            binding = null;
            return true;
        }

        long window = client.getWindow().getHandle();
        if (System.currentTimeMillis() - openTime > 400 && theme.menuMatches(keyCode, window)) {
            close();
            return true;
        }

        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && !search.isEmpty()) {
            search = "";
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        Sfx.close();
        super.close();
    }

    @Override
    public void removed() {
        ConfigManager.save(Md5n.modules);
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

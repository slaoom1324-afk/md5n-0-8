package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.Locale;

public class TriggerBot extends Module {
    private final NumSetting minCooldown = num("Min Cooldown", 0.95, 0, 1, 0.05, "Attack only when your weapon is this charged");
    private final BoolSetting players = bool("Players", true, "Attack players under the crosshair");
    private final BoolSetting hostile = bool("Hostile", true, "Attack hostile mobs under the crosshair");
    private final BoolSetting passive = bool("Passive", true, "Attack animals and villagers under the crosshair");
    private final BoolSetting pauseUsingItem = bool("Pause When Using Item", true, "Don't attack while eating or drawing a bow");
    private final BoolSetting debug = bool("Debug", false, "Show what the crosshair sees in the action bar");

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT, "Auto-attacks when your crosshair is on a target");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;

        HitResult hit = mc.crosshairTarget;

        if (debug.get()) {
            String seen = (hit instanceof EntityHitResult seenHit) ? seenHit.getEntity().getName().getString() : "nothing";
            mc.inGameHud.setOverlayMessage(Text.literal("TriggerBot: " + seen + " | charge "
                    + String.format(Locale.ROOT, "%.2f", mc.player.getAttackCooldownProgress(0.5f))), false);
        }

        if (pauseUsingItem.get() && mc.player.isUsingItem()) return;
        if (!(hit instanceof EntityHitResult entityHit)) return;

        Entity entity = entityHit.getEntity();
        if (!Targets.valid(entity, players.get(), hostile.get(), passive.get())) return;
        LivingEntity target = (LivingEntity) entity;

        if (mc.player.getAttackCooldownProgress(0.5f) < minCooldown.getFloat()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}

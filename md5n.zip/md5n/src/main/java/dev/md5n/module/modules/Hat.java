package dev.md5n.module.modules;

import dev.md5n.util.Colors;

public class Hat extends Cosmetic {
    public Hat() {
        super("Hat", "Particle hats floating above your head (press F5 to see)",
                new String[]{"Halo", "Crown", "Top Hat", "Wizard", "Horns", "Orbs", "Cat Ears", "Flame Crown", "Star", "Storm Cloud"});
    }

    @Override
    protected void emit(String s) {
        double h = height;
        double sz = size.get();

        switch (s) {
            case "Crown": {
                hring(0, h + 0.02, 0, 0.28 * sz, 12, 0.0, col(0.0));
                for (int k = 0; k < 5; k++) {
                    double a = k * TAU / 5 + t * 0.5;
                    for (int j = 1; j <= 3; j++) {
                        put(Math.cos(a) * 0.28 * sz, h + 0.02 + j * 0.07 * sz, Math.sin(a) * 0.28 * sz, col(k / 5.0));
                    }
                }
                break;
            }
            case "Top Hat": {
                hring(0, h + 0.02, 0, 0.40 * sz, 14, 0.0, col(0.0));
                hring(0, h + 0.02, 0, 0.25 * sz, 10, 0.0, col(0.3));
                hring(0, h + 0.02 + 0.40 * sz, 0, 0.25 * sz, 10, 0.0, col(0.6));
                hring(0, h + 0.02 + 0.40 * sz, 0, 0.12 * sz, 6, 0.0, col(0.8));
                for (int k = 0; k < 4; k++) {
                    double a = k * TAU / 4;
                    double px = Math.cos(a) * 0.25 * sz;
                    double pz = Math.sin(a) * 0.25 * sz;
                    line(px, h + 0.02, pz, px, h + 0.02 + 0.40 * sz, pz, 4, col(k / 4.0));
                }
                break;
            }
            case "Wizard": {
                int pts = 22;
                for (int i = 0; i < pts; i++) {
                    double f = i / (double) pts;
                    double r = 0.38 * sz * (1.0 - f);
                    double a = f * TAU * 2.0 + t * 0.6;
                    put(Math.cos(a) * r + f * f * 0.12 * sz, h + 0.02 + f * 0.7 * sz, Math.sin(a) * r, col(f));
                }
                hring(0, h + 0.02, 0, 0.42 * sz, 12, 0.0, col(0.0));
                break;
            }
            case "Horns": {
                for (int side = -1; side <= 1; side += 2) {
                    for (int j = 0; j <= 6; j++) {
                        double f = j / 6.0;
                        put(side * (0.14 + 0.26 * Math.sin(f * Math.PI / 2.0)) * sz, h - 0.03 + f * 0.42 * sz, 0.02, col(f));
                    }
                }
                break;
            }
            case "Orbs": {
                for (int k = 0; k < 3; k++) {
                    double a = t * 2.5 + k * TAU / 3;
                    double ox = Math.cos(a) * 0.42 * sz;
                    double oz = Math.sin(a) * 0.42 * sz;
                    double oy = h + 0.3 + 0.06 * Math.sin(t * 3.0 + k);
                    put(ox, oy, oz, col(k / 3.0));
                    put(ox + 0.02, oy + 0.02, oz, col(k / 3.0));
                }
                break;
            }
            case "Cat Ears": {
                for (int side = -1; side <= 1; side += 2) {
                    double b1 = side * 0.10;
                    double b2 = side * 0.30;
                    double ap = side * 0.22;
                    line(b1, h, 0.0, ap, h + 0.28 * sz, 0.0, 4, col(0.2));
                    line(b2, h, 0.0, ap, h + 0.28 * sz, 0.0, 4, col(0.5));
                    line(b1, h, 0.0, b2, h, 0.0, 3, col(0.8));
                }
                break;
            }
            case "Flame Crown": {
                int cnt = n(8);
                for (int i = 0; i < cnt; i++) {
                    double a = rnd() * TAU;
                    int c = Colors.lerp(col(rnd()), 0xFF7A18, 0.5);
                    putV(Math.cos(a) * 0.28 * sz, h + 0.05, Math.sin(a) * 0.28 * sz, c, 0.0, 0.05 + rnd() * 0.04, 0.0);
                }
                break;
            }
            case "Star": {
                double[] sx = new double[5];
                double[] sz2 = new double[5];
                for (int k = 0; k < 5; k++) {
                    double a = t * 0.8 + k * TAU / 5;
                    sx[k] = Math.cos(a) * 0.35 * sz;
                    sz2[k] = Math.sin(a) * 0.35 * sz;
                }
                for (int k = 0; k < 5; k++) {
                    int m = (k + 2) % 5;
                    line(sx[k], h + 0.3, sz2[k], sx[m], h + 0.3, sz2[m], 5, col(k / 5.0));
                }
                break;
            }
            case "Storm Cloud": {
                int cnt = n(6);
                for (int i = 0; i < cnt; i++) {
                    put(spread(0.25 * sz), h + 0.35 + rnd() * 0.12, spread(0.25 * sz), Colors.lerp(col(rnd()), 0xC8CCD8, 0.55));
                }
                if (tick % 25 == 0) {
                    line(0.0, h + 0.33, 0.0, spread(0.15), h + 0.02, spread(0.15), 6, 0xFFF59D);
                }
                break;
            }
            default: {
                // Halo
                hring(0, h + 0.25 * sz, 0, 0.32 * sz, 14, t * 2.0, col(0.0));
                break;
            }
        }
    }
}

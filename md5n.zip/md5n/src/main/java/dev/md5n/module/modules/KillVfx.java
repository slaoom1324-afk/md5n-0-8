package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.KeySetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Sfx;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class KillVfx extends Module {
    private static final String[] TYPES = {
            "Burst", "Soul Rise", "Lightning", "Totem", "Ring Wave",
            "Meteor", "Portal", "Hearts", "Cherry", "Galaxy"
    };

    private final ModeSetting type = mode("Type", "Burst",
            "Effect played when you kill someone. Random picks a different one each kill",
            "Burst", "Soul Rise", "Lightning", "Totem", "Ring Wave",
            "Meteor", "Portal", "Hearts", "Cherry", "Galaxy", "Random");
    private final NumSetting intensity = num("Intensity", 1.0, 0.5, 3.0, 0.1, "How many particles the effect uses");
    private final BoolSetting sound = bool("Sound", true, "Play a small jingle with the effect");
    private final BoolSetting includeMobs = bool("Include Mobs", false, "Also play the effect when you kill mobs");
    private final KeySetting testKey = keybind("Test Key", GLFW.GLFW_KEY_J, "Press to preview the effect in front of you");

    private static final class Track {
        int lastAttack;
        Vec3d pos;
        float health;
    }

    private static final class Active {
        final Vec3d pos;
        final String type;
        int age;

        Active(Vec3d pos, String type) {
            this.pos = pos;
            this.type = type;
        }
    }

    private final Map<Integer, Track> tracks = new HashMap<>();
    private final List<Active> effects = new ArrayList<>();
    private int tickCount;

    public KillVfx() {
        super("Kill VFX", Category.VFX, "Particle animations when you kill a player");

        // نسجّل آخر كيان ضربته، ونراقبه لين يموت
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (player == mc.player) onAttack(entity);
            return ActionResult.PASS;
        });
    }

    @Override
    protected void onDisable() {
        tracks.clear();
        effects.clear();
    }

    private void onAttack(Entity entity) {
        if (!isEnabled()) return;
        if (!(entity instanceof LivingEntity living)) return;
        boolean isPlayer = entity instanceof PlayerEntity;
        if (!isPlayer && !includeMobs.get()) return;

        Track t = tracks.computeIfAbsent(entity.getId(), k -> new Track());
        t.lastAttack = tickCount;
        t.pos = living.getPos();
        t.health = living.getHealth();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        tickCount++;

        // مفتاح التجربة
        if (mc.currentScreen == null && testKey.consumePress(mc.getWindow().getHandle())) {
            Vec3d look = mc.player.getRotationVec(1.0f);
            Vec3d at = mc.player.getPos().add(look.x * 3.0, 0.0, look.z * 3.0);
            start(at);
        }

        // راقب اللي ضربتهم
        Iterator<Map.Entry<Integer, Track>> it = tracks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Track> en = it.next();
            Track t = en.getValue();
            Entity e = mc.world.getEntityById(en.getKey());

            if (e instanceof LivingEntity living) {
                if (living.isDead() || living.getHealth() <= 0f) {
                    start(living.getPos());
                    it.remove();
                    continue;
                }
                t.pos = living.getPos();
                t.health = living.getHealth();
            } else if (e == null && tickCount - t.lastAttack <= 40 && t.health <= 6f && t.pos != null) {
                // اختفى بعد الضربة وصحته كانت قليلة
                start(t.pos);
                it.remove();
                continue;
            }

            if (tickCount - t.lastAttack > 100) it.remove();
        }

        // شغّل التأثيرات الجارية
        Iterator<Active> ei = effects.iterator();
        while (ei.hasNext()) {
            Active a = ei.next();
            if (step(a)) ei.remove();
            else a.age++;
        }
    }

    private void start(Vec3d pos) {
        String chosen = type.get();
        if (chosen.equals("Random")) {
            chosen = TYPES[ThreadLocalRandom.current().nextInt(TYPES.length)];
        }
        effects.add(new Active(pos, chosen));
    }

    // ------------------------------------------------------------ أدوات

    private int scaled(double base) {
        double v = base * intensity.get();
        int n = (int) v;
        if (ThreadLocalRandom.current().nextDouble() < v - n) n++;
        return n;
    }

    private static double rnd() {
        return ThreadLocalRandom.current().nextDouble();
    }

    private static double[] randomDir() {
        double u = rnd() * 2.0 - 1.0;
        double th = rnd() * Math.PI * 2.0;
        double s = Math.sqrt(1.0 - u * u);
        return new double[]{s * Math.cos(th), u, s * Math.sin(th)};
    }

    private void p(ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz) {
        mc.world.addParticle(effect, x, y, z, vx, vy, vz);
    }

    private void chime() {
        if (!sound.get()) return;
        Sfx.note(1.0f);
        Sfx.note(1.26f);
        Sfx.note(1.5f);
    }

    private void rumble() {
        if (!sound.get()) return;
        Sfx.note(0.5f);
        Sfx.note(0.56f);
        Sfx.note(0.63f);
    }

    // ------------------------------------------------------------ الأنيميشن

    /** يرجع true لما يخلص التأثير. */
    private boolean step(Active a) {
        double x = a.pos.x, y = a.pos.y, z = a.pos.z;
        int age = a.age;

        switch (a.type) {
            case "Soul Rise": {
                if (age == 0) chime();
                int arms = scaled(2);
                for (int i = 0; i < arms; i++) {
                    double ang = age * 0.4 + i * Math.PI;
                    double r = 0.8 - age * 0.006;
                    p(ParticleTypes.SOUL, x + Math.cos(ang) * r, y + 0.2 + age * 0.07, z + Math.sin(ang) * r, 0.0, 0.04, 0.0);
                }
                if (age % 3 == 0) p(ParticleTypes.SOUL_FIRE_FLAME, x, y + 0.2 + age * 0.07, z, 0.0, 0.03, 0.0);
                return age >= 50;
            }
            case "Lightning": {
                if (age == 0) {
                    rumble();
                    int n = scaled(30);
                    for (int i = 0; i < n; i++) {
                        double ang = i * Math.PI * 2.0 / n;
                        p(ParticleTypes.CLOUD, x + Math.cos(ang) * 0.4, y + 0.1, z + Math.sin(ang) * 0.4,
                                Math.cos(ang) * 0.25, 0.05, Math.sin(ang) * 0.25);
                    }
                }
                if (age < 5) {
                    double jx = 0.0, jz = 0.0;
                    for (double h = 0.0; h <= 16.0; h += 0.6) {
                        jx += (rnd() - 0.5) * 0.5;
                        jz += (rnd() - 0.5) * 0.5;
                        double f = h / 16.0;
                        p(ParticleTypes.ELECTRIC_SPARK, x + jx * f, y + h, z + jz * f, 0.0, 0.0, 0.0);
                        if (rnd() < 0.5) p(ParticleTypes.END_ROD, x + jx * f, y + h, z + jz * f, 0.0, 0.0, 0.0);
                    }
                }
                return age >= 12;
            }
            case "Totem": {
                if (age == 0) {
                    chime();
                    int n = scaled(90);
                    for (int i = 0; i < n; i++) {
                        double[] d = randomDir();
                        double sp = 0.2 + rnd() * 0.5;
                        p(ParticleTypes.TOTEM_OF_UNDYING, x, y + 1.0, z, d[0] * sp, Math.abs(d[1]) * sp + 0.2, d[2] * sp);
                    }
                }
                return age >= 2;
            }
            case "Ring Wave": {
                if (age == 0) chime();
                double r = 0.3 + age * 0.32;
                int pts = 24 + (int) (8 * intensity.get());
                for (int i = 0; i < pts; i++) {
                    double ang = i * Math.PI * 2.0 / pts;
                    p(ParticleTypes.END_ROD, x + Math.cos(ang) * r, y + 0.15, z + Math.sin(ang) * r,
                            Math.cos(ang) * 0.02, 0.01, Math.sin(ang) * 0.02);
                }
                if (age % 3 == 0) {
                    for (int i = 0; i < pts / 2; i++) {
                        double ang = i * Math.PI * 4.0 / pts;
                        p(ParticleTypes.ENCHANTED_HIT, x + Math.cos(ang) * r * 0.7, y + 0.3, z + Math.sin(ang) * r * 0.7, 0.0, 0.05, 0.0);
                    }
                }
                return age >= 24;
            }
            case "Meteor": {
                if (age < 18) {
                    double prog = age / 18.0;
                    double px = x + (1.0 - prog) * 6.0;
                    double py = y + (1.0 - prog) * 20.0;
                    double pz = z + (1.0 - prog) * 3.0;
                    int n = scaled(3);
                    for (int i = 0; i < n; i++) {
                        p(ParticleTypes.FLAME, px + (rnd() - 0.5) * 0.5, py + (rnd() - 0.5) * 0.5, pz + (rnd() - 0.5) * 0.5, 0.0, 0.02, 0.0);
                        p(ParticleTypes.LARGE_SMOKE, px, py, pz, (rnd() - 0.5) * 0.05, 0.03, (rnd() - 0.5) * 0.05);
                    }
                } else if (age == 18) {
                    rumble();
                    p(ParticleTypes.EXPLOSION_EMITTER, x, y + 0.5, z, 0.0, 0.0, 0.0);
                    int n = scaled(40);
                    for (int i = 0; i < n; i++) {
                        double ang = i * Math.PI * 2.0 / n;
                        p(ParticleTypes.FLAME, x, y + 0.2, z, Math.cos(ang) * 0.3, 0.08, Math.sin(ang) * 0.3);
                    }
                }
                return age >= 28;
            }
            case "Portal": {
                if (age < 24) {
                    int n = scaled(6);
                    for (int i = 0; i < n; i++) {
                        double ang = rnd() * Math.PI * 2.0;
                        double px = x + Math.cos(ang) * 2.5;
                        double py = y + 0.2 + rnd() * 2.0;
                        double pz = z + Math.sin(ang) * 2.5;
                        p(ParticleTypes.PORTAL, px, py, pz, x - px, y + 1.0 - py, z - pz);
                    }
                } else if (age == 24) {
                    if (sound.get()) Sfx.note(0.7f);
                    int n = scaled(50);
                    for (int i = 0; i < n; i++) {
                        double[] d = randomDir();
                        p(ParticleTypes.REVERSE_PORTAL, x, y + 1.0, z, d[0] * 0.25, d[1] * 0.25, d[2] * 0.25);
                    }
                }
                return age >= 32;
            }
            case "Hearts": {
                if (age == 0) chime();
                int n = scaled(age == 0 ? 8 : 2);
                for (int i = 0; i < n; i++) {
                    p(ParticleTypes.HEART, x + (rnd() - 0.5) * 1.2, y + 0.5 + rnd() * 1.2, z + (rnd() - 0.5) * 1.2, 0.0, 0.05, 0.0);
                }
                return age >= 30;
            }
            case "Cherry": {
                if (age == 0) chime();
                int n = scaled(4);
                for (int i = 0; i < n; i++) {
                    double ang = rnd() * Math.PI * 2.0;
                    double r = 0.3 + rnd() * 1.5;
                    p(ParticleTypes.CHERRY_LEAVES, x + Math.cos(ang) * r, y + 0.5 + rnd() * 2.2, z + Math.sin(ang) * r,
                            -Math.sin(ang) * 0.06, 0.02, Math.cos(ang) * 0.06);
                }
                return age >= 50;
            }
            case "Galaxy": {
                if (age == 0) chime();
                for (int arm = 0; arm < 3; arm++) {
                    double ang = age * 0.28 + arm * Math.PI * 2.0 / 3.0;
                    double r = 0.4 + age * 0.035;
                    p(ParticleTypes.END_ROD, x + Math.cos(ang) * r, y + 0.2 + age * 0.045, z + Math.sin(ang) * r, 0.0, 0.01, 0.0);
                }
                int n = scaled(2);
                for (int i = 0; i < n; i++) {
                    p(ParticleTypes.ENCHANT, x, y + 0.8 + age * 0.02, z, (rnd() - 0.5) * 0.6, rnd() * 0.3, (rnd() - 0.5) * 0.6);
                }
                return age >= 64;
            }
            default: {
                // Burst
                if (age == 0) {
                    chime();
                    int n = scaled(70);
                    for (int i = 0; i < n; i++) {
                        double[] d = randomDir();
                        double sp = 0.25 + rnd() * 0.45;
                        p(ParticleTypes.FIREWORK, x, y + 1.0, z, d[0] * sp, d[1] * sp + 0.1, d[2] * sp);
                    }
                    int c = scaled(25);
                    for (int i = 0; i < c; i++) {
                        double[] d = randomDir();
                        p(ParticleTypes.CRIT, x, y + 1.0, z, d[0] * 0.6, d[1] * 0.6, d[2] * 0.6);
                    }
                }
                return age >= 2;
            }
        }
    }
}

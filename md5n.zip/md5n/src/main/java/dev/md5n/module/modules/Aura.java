package dev.md5n.module.modules;

import dev.md5n.util.Colors;

public class Aura extends Cosmetic {
    public Aura() {
        super("Aura", "Particle aura around your body (press F5 to see)",
                new String[]{"Rings", "Spiral", "Orbit", "Shell", "Pulse", "Flames", "Vortex", "Electric", "Bubbles", "Constellation"});
    }

    private void sphere(double r, double cy, int rgb) {
        double u = rnd() * 2.0 - 1.0;
        double th = rnd() * TAU;
        double s = Math.sqrt(1.0 - u * u);
        put(r * s * Math.cos(th), cy + r * u, r * s * Math.sin(th), rgb);
    }

    @Override
    protected void emit(String s) {
        double h = height;
        double sz = size.get();

        switch (s) {
            case "Spiral": {
                for (int k = 0; k < 2; k++) {
                    for (int j = 0; j < 10; j++) {
                        double f = j / 10.0;
                        double a = f * TAU * 2.0 + t * 2.5 + k * Math.PI;
                        put(Math.cos(a) * 0.55 * sz, f * h, Math.sin(a) * 0.55 * sz, col(f));
                    }
                }
                break;
            }
            case "Orbit": {
                for (int k = 0; k < 4; k++) {
                    double a = t * 2.0 + k * TAU / 4;
                    double y = h * 0.5 + 0.15 * Math.sin(t * 2.0 + k);
                    put(Math.cos(a) * 0.8 * sz, y, Math.sin(a) * 0.8 * sz, col(k / 4.0));
                    put(Math.cos(a) * 0.8 * sz, y + 0.04, Math.sin(a) * 0.8 * sz, col(k / 4.0));
                }
                break;
            }
            case "Shell": {
                int cnt = n(10);
                for (int i = 0; i < cnt; i++) sphere(0.95 * sz, h * 0.5, col(rnd()));
                break;
            }
            case "Pulse": {
                double r = (0.6 + 0.35 * (0.5 + 0.5 * Math.sin(t * 2.5))) * sz;
                int cnt = n(12);
                for (int i = 0; i < cnt; i++) sphere(r, h * 0.5, col(rnd()));
                break;
            }
            case "Flames": {
                int cnt = n(8);
                for (int i = 0; i < cnt; i++) {
                    double a = rnd() * TAU;
                    int c = Colors.lerp(col(rnd()), 0xFF7A18, 0.45);
                    putV(Math.cos(a) * 0.45 * sz, 0.05 + rnd() * 0.35, Math.sin(a) * 0.45 * sz, c, 0.0, 0.08, 0.0);
                }
                break;
            }
            case "Vortex": {
                for (int idx = 0; idx < 3; idx++) {
                    double dir = (idx % 2 == 0) ? 1.0 : -1.0;
                    hring(0, h * (0.3 + 0.25 * idx), 0, 0.6 * sz, 10, dir * t * 3.0, col(idx / 3.0));
                }
                break;
            }
            case "Electric": {
                int cnt = n(4);
                for (int i = 0; i < cnt; i++) {
                    double a = rnd() * TAU;
                    double bx = Math.cos(a) * 0.6 * sz;
                    double bz = Math.sin(a) * 0.6 * sz;
                    double by = rnd() * h;
                    int c = Colors.lerp(col(rnd()), 0xFFFFFF, 0.4);
                    for (int j = 0; j < 4; j++) {
                        put(bx + spread(0.12) * j, by + spread(0.12) * j, bz + spread(0.12) * j, c);
                    }
                }
                break;
            }
            case "Bubbles": {
                int cnt = n(5);
                for (int i = 0; i < cnt; i++) {
                    double a = rnd() * TAU;
                    double r = rnd() * 0.7 * sz;
                    putV(Math.cos(a) * r, rnd() * h, Math.sin(a) * r, col(rnd()), 0.0, 0.03, 0.0);
                }
                break;
            }
            case "Constellation": {
                double[] nx = new double[6];
                double[] ny = new double[6];
                double[] nz = new double[6];
                for (int k = 0; k < 6; k++) {
                    double a = t * 0.8 + k * TAU / 6;
                    nx[k] = Math.cos(a) * 0.9 * sz;
                    nz[k] = Math.sin(a) * 0.9 * sz;
                    ny[k] = h * 0.5 + 0.3 * Math.sin(k * 1.7 + t);
                    put(nx[k], ny[k], nz[k], 0xFFFFFF);
                }
                for (int k = 0; k < 6; k++) {
                    int m = (k + 1) % 6;
                    line(nx[k], ny[k], nz[k], nx[m], ny[m], nz[m], 3, col(k / 6.0));
                }
                break;
            }
            default: {
                // Rings
                for (int k = 0; k < 2; k++) {
                    double y = ((t * 0.8 + k * 0.5) % 1.0) * h;
                    hring(0, y, 0, (0.55 + 0.08 * Math.sin(t * 3.0)) * sz, 16, t, col(k / 2.0));
                }
                break;
            }
        }
    }
}

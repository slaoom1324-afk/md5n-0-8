package dev.md5n.module.modules;

import dev.md5n.util.Colors;

public class Cape extends Cosmetic {
    public Cape() {
        super("Cape", "A cape made of particles hanging from your shoulders (press F5 to see)",
                new String[]{"Classic", "Royal", "Flowing", "Flames", "Starry", "Gradient", "Swallowtail", "Short Cloak", "Tattered", "Rainbow"});
    }

    @Override
    protected void emit(String s) {
        double sz = size.get();
        double w = 0.5 * sz;
        double len = 0.95 * sz;
        double y0 = height * 0.82;
        if (s.equals("Short Cloak")) {
            w = 0.75 * sz;
            len = 0.55 * sz;
        }

        int cnt = n(s.equals("Starry") ? 16 : 14);
        for (int i = 0; i < cnt; i++) {
            double u = rnd();
            double v = rnd();
            if (s.equals("Swallowtail") && v > 0.6 + 0.4 * Math.abs(2.0 * u - 1.0)) continue;
            if (s.equals("Tattered") && v > 0.6 && rnd() < (v - 0.6) * 1.6) continue;

            double lx = (u - 0.5) * w;
            double ly = y0 - v * len;
            double lz = -0.24 - v * (0.08 + speed * 0.9) + Math.sin(t * 2.0 + v * 3.0) * 0.03;
            if (s.equals("Flowing")) {
                lz += Math.sin(t * 3.0 + v * 5.0 + u * 2.0) * 0.12 * (0.3 + speed * 3.0);
            }

            int base = col(u);
            int rgb;
            switch (s) {
                case "Royal":
                    rgb = (v > 0.9 || u < 0.06 || u > 0.94) ? 0xFFD54F : base;
                    break;
                case "Flames":
                    rgb = Colors.lerp(base, 0xFF5A14, v);
                    break;
                case "Starry":
                    rgb = rnd() < 0.18 ? 0xFFFFFF : Colors.scale(base, 0.45);
                    break;
                case "Gradient":
                    rgb = Colors.lerp(base, Colors.hueShift(base, 55.0), v);
                    break;
                case "Rainbow":
                    rgb = Colors.hsv((u * 0.6 + v * 0.4 + t * 0.05) % 1.0, 0.6, 1.0);
                    break;
                default:
                    rgb = base;
                    break;
            }

            double vy = (s.equals("Flames") && v > 0.8) ? 0.05 : 0.0;
            putV(lx, ly, lz, rgb, 0.0, vy, 0.0);
        }
    }
}

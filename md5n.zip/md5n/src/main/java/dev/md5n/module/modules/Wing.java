package dev.md5n.module.modules;

import dev.md5n.util.Colors;
import dev.md5n.util.Fx;

public class Wing extends Cosmetic {
    private double extraVy;

    public Wing() {
        super("Wing", "Particle wings on your back that flap (press F5 to see)",
                new String[]{"Angel", "Demon", "Butterfly", "Dragon", "Fairy", "Phoenix", "Crystal", "Mech", "Ghost", "Void"});
    }

    /** اتجاه ريشة: side = -1/+1، phi = زاوية فتح الجناح، alpha = ميلان الريشة لفوق. */
    private double[] dir(int side, double phiDeg, double alphaDeg) {
        double phi = Math.toRadians(phiDeg);
        double al = Math.toRadians(alphaDeg);
        return new double[]{side * Math.cos(phi) * Math.cos(al), Math.sin(al), -Math.sin(phi) * Math.cos(al)};
    }

    private double[] pointOn(int side, double phi, double alpha, double len) {
        double[] d = dir(side, phi, alpha);
        double sz = size.get();
        return new double[]{
                side * 0.12 + d[0] * len * sz,
                height * 0.78 + d[1] * len * sz,
                -0.18 + d[2] * len * sz
        };
    }

    private void dot(double[] p, int rgb) {
        putV(p[0], p[1], p[2], rgb, 0.0, extraVy, 0.0);
    }

    private void seg(double[] a, double[] b, int cnt, int rgb) {
        for (int i = 0; i < cnt; i++) {
            double f = rnd();
            dot(new double[]{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f}, rgb);
        }
    }

    private void feather(int side, double phi, double alpha, double len, int cnt, int c0, int c1) {
        double[] a = pointOn(side, phi, alpha, 0.0);
        double[] b = pointOn(side, phi, alpha, len);
        for (int i = 0; i < cnt; i++) {
            double f = rnd();
            dot(new double[]{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f},
                    Colors.lerp(c0, c1, f));
        }
    }

    private void lobe(int side, double phi, double alphaC, double dist, double radius, int cnt, int rgb) {
        double[] c = pointOn(side, phi, alphaC, dist);
        double[] o = dir(side, phi, 0.0);
        double r = radius * size.get();
        for (int i = 0; i < cnt; i++) {
            double th = rnd() * TAU;
            dot(new double[]{c[0] + o[0] * Math.cos(th) * r, c[1] + Math.sin(th) * r, c[2] + o[2] * Math.cos(th) * r}, rgb);
        }
    }

    private void poly(int side, double phi, double alphaC, double dist, double radius, int sides, int cnt, int rgb) {
        double[] c = pointOn(side, phi, alphaC, dist);
        double[] o = dir(side, phi, 0.0);
        double r = radius * size.get();
        for (int k = 0; k < sides; k++) {
            double a1 = k * TAU / sides;
            double a2 = (k + 1) * TAU / sides;
            double[] p1 = {c[0] + o[0] * Math.cos(a1) * r, c[1] + Math.sin(a1) * r, c[2] + o[2] * Math.cos(a1) * r};
            double[] p2 = {c[0] + o[0] * Math.cos(a2) * r, c[1] + Math.sin(a2) * r, c[2] + o[2] * Math.cos(a2) * r};
            seg(p1, p2, cnt, rgb);
        }
    }

    @Override
    protected void emit(String s) {
        extraVy = 0.0;
        int c0 = col(0.0);
        int c1 = Colors.lerp(c0, 0xFFFFFF, 0.55);

        for (int side = -1; side <= 1; side += 2) {
            switch (s) {
                case "Demon": {
                    double phi = 60 + 10 * Math.sin(t * 1.8);
                    double[] alphas = {70, 45, 20, -5};
                    double[] lens = {0.95, 0.9, 0.8, 0.65};
                    double[][] tips = new double[4][];
                    for (int i = 0; i < 4; i++) {
                        feather(side, phi, alphas[i], lens[i], n(2), c0, Colors.scale(c0, 0.6));
                        tips[i] = pointOn(side, phi, alphas[i], lens[i]);
                    }
                    for (int i = 0; i < 3; i++) seg(tips[i], tips[i + 1], n(2), Colors.scale(c0, 0.8));
                    break;
                }
                case "Butterfly": {
                    double phi = 55 + 14 * Math.sin(t * 2.2);
                    lobe(side, phi, 45, 0.45, 0.42, n(6), c0);
                    lobe(side, phi, -15, 0.35, 0.28, n(4), c1);
                    break;
                }
                case "Dragon": {
                    double phi = 50 + 14 * Math.sin(t * 1.8);
                    double[] alphas = {80, 55, 30, 5, -20};
                    double[] lens = {1.0, 1.05, 0.9, 0.75, 0.55};
                    double[][] tips = new double[5][];
                    for (int i = 0; i < 5; i++) {
                        feather(side, phi, alphas[i], lens[i], n(2), c0, Colors.scale(c0, 0.55));
                        tips[i] = pointOn(side, phi, alphas[i], lens[i]);
                    }
                    for (int i = 0; i < 4; i++) seg(tips[i], tips[i + 1], n(2), Colors.scale(c0, 0.75));
                    break;
                }
                case "Fairy": {
                    double phi = 50 + 20 * Math.sin(t * 9.0);
                    lobe(side, phi, 50, 0.3, 0.30, n(4), c1);
                    lobe(side, phi, -10, 0.25, 0.20, n(3), c0);
                    break;
                }
                case "Phoenix": {
                    extraVy = 0.03;
                    double phi = 55 + 8 * Math.sin(t * 2.0);
                    for (int i = 0; i < 8; i++) {
                        feather(side, phi, 75 - i * 12, 1.2 - i * 0.09, n(2), Colors.lerp(c0, 0xFF6A1A, 0.5), 0xFFD54F);
                    }
                    break;
                }
                case "Crystal": {
                    double phi = 55 + 6 * Math.sin(t * 1.5);
                    poly(side, phi, 40, 0.45, 0.30, 6, n(2), c1);
                    poly(side, phi, -15, 0.35, 0.20, 6, n(2), c0);
                    break;
                }
                case "Mech": {
                    double phi = 55 + 5 * Math.sin(t * 1.5);
                    for (int i = 0; i < 3; i++) {
                        double alpha = 60 - i * 28;
                        double len = 0.9 - i * 0.12;
                        feather(side, phi, alpha + 3, len, n(2), c0, c0);
                        feather(side, phi, alpha - 3, len, n(2), c1, c1);
                        seg(pointOn(side, phi, alpha + 3, len), pointOn(side, phi, alpha - 3, len), 1, c1);
                    }
                    break;
                }
                case "Ghost": {
                    double phi = 55 + 8 * Math.sin(t * 1.6);
                    int gc = Colors.lerp(c0, 0xFFFFFF, 0.6);
                    for (int i = 0; i < 7; i++) {
                        feather(side, phi, 75 - i * 14 + spread(4.0), 1.0 - i * 0.08, n(2), gc, c0);
                    }
                    if (rnd() < 0.25) {
                        double[] p = pointOn(side, phi, 40, rnd());
                        Fx.vfx("Soul", worldX(p[0], p[2]), ay + p[1], worldZ(p[0], p[2]), 0.0, 0.02, 0.0);
                    }
                    break;
                }
                case "Void": {
                    double phi = 58 + 10 * Math.sin(t * 1.7);
                    double[] alphas = {85, 60, 35, 15, -10, -30};
                    for (int i = 0; i < alphas.length; i++) {
                        double len = (i % 2 == 0) ? 1.1 : 0.7;
                        feather(side, phi, alphas[i], len, n(2), c0, Colors.lerp(c0, 0x2B0A55, 0.7));
                    }
                    if (rnd() < 0.25) {
                        double[] p = pointOn(side, phi, 30, rnd());
                        Fx.vfx("Portal", worldX(p[0], p[2]), ay + p[1], worldZ(p[0], p[2]), 0.0, 0.0, 0.0);
                    }
                    break;
                }
                default: {
                    // Angel
                    double phi = 55 + 8 * Math.sin(t * 2.0);
                    for (int i = 0; i < 7; i++) {
                        feather(side, phi, 75 - i * 14, 0.95 - i * 0.07, n(2), c0, c1);
                    }
                    break;
                }
            }
        }
    }
}
